# MFD — Multi-Function Device v4
**Geliştirici: Mehmet Fatih DURSUN**

## Proje Özeti
MFD, Android için geliştirilmiş yapay zekâ destekli kişisel sesli asistan uygulamasıdır.  
Gemini API kullanarak cihazı sesli veya yazılı komutlarla kontrol eder.

---

## v4 Yenilikleri & Düzeltmeler

### 🐛 Hata Düzeltmeleri
- **GeminiClient history yönetimi**: `functionCall` geçmişi artık Gemini API formatına uygun kaydediliyor (functionCall parçaları model turn'da korunuyor)
- **Tool declarations tip uyumu**: Tüm araç parametreleri INTEGER/STRING/BOOLEAN olarak doğru tipleendi
- **history trim**: Kullanıcı turn ile başlaması zorunluluğu korunuyor (API 400 hatası giderildi)
- **minSdkVersion 24'e düşürüldü** (v3'te 26 idi) — daha geniş cihaz desteği
- **SmsManager API guard**: Android 12+ için `getSystemService(SmsManager.class)` koşullu kullanılıyor
- **TTS dil ayarı**: `LANG_MISSING_DATA` / `LANG_NOT_SUPPORTED` durumlarında sistem diline geri dönüş
- **SpeechRecognizer hata yönetimi**: `ERROR_NO_MATCH` ve `ERROR_SPEECH_TIMEOUT` sessizce yutulur
- **NetworkCapabilities**: API 23+ için eski `NetworkInfo` yerine `NetworkCapabilities` kullanılıyor
- **MFDNotificationListener**: `java.util.Set` gereksiz import kaldırıldı; `RemoteInput` düzeltildi
- **ChatLogAdapter**: Renk arka planı yerine `GradientDrawable` ile yuvarlatılmış köşeler
- **MainActivity onResume**: Ayarlar değişince Gemini otomatik yenileniyor
- **FloatingBubbleService**: `motionEvent.ACTION_UP` sırasında hem sürükleme hem tıklama doğru ayrılıyor
- **WakeWordService**: Crash sonrası 1 saniye bekleme ile yeniden başlatma (pil dostu)

### ✨ Yeni Özellikler
- **Hızlı erişim kartları**: Ana ekranda kaydırılabilir komut kısayolları (hava, pil, takvim, müzik…)
- **onResume Gemini yenileme**: Ayarlar ekranından döndükten sonra yeni tercihler anında aktif
- **toolConfig AUTO modu**: Model araç çağrısı yapıp yapmamaya kendi karar veriyor
- **Daha kısa TTS**: Sistem prompt optimize edildi, sesli yanıtlar daha kısa ve net
- **GeminiClient maxOutputTokens 1500**: Daha uzun cevaplara izin verildi
- **Alarm/Hatırlatıcı**: ISO tarih-saatinden otomatik saat/dakika ayrıştırma

### 🎨 Arayüz
- Koyu tema renk paleti güncellendi
- Chat balonları `GradientDrawable` ile gerçek yuvarlatılmış köşe
- OrbView animasyon geçişleri daha akıcı
- Status row kompakt hale getirildi

---

## Kurulum
1. **Gemini API Anahtarı Alma**: [Google AI Studio](https://aistudio.google.com) → API Key Oluştur (ücretsiz)
2. APK'yı cihaza kur, uygulamayı aç
3. API anahtarını, adınızı ve şehrinizi girin
4. "Test Et" → çalışan model otomatik bulunur → "Kaydet"

## Desteklenen Komutlar (Örnekler)
| Komut | İşlem |
|---|---|
| "Yarın sabah 7'ye alarm kur" | Alarm kurulur |
| "YouTube'da Tarkan aç" | YouTube araması |
| "Ahmet'e WhatsApp mesajı yaz" | Onay sonrası WA açılır |
| "Hava durumu nasıl?" | Anlık hava |
| "Feneri aç" | Cep feneri |
| "Dolar kaç lira?" | Döviz kuru |
| "Bugünkü etkinliklerimi göster" | Takvim |
| "Toplantı başlamadan 5 dakika önce hatırlat" | Timer |

## Teknik
- minSdkVersion: 24 (Android 7.0+)
- targetSdkVersion: 34
- Dil: Java
- AI: Google Gemini API (gemini-2.5-flash)
- TTS/STT: Android yerleşik
- Ağ: wttr.in (hava), open.er-api.com (döviz), Gemini API

## Gizlilik
Konuşmalar yalnızca Gemini API'ye iletilir. Yerel hafıza SharedPreferences'ta saklanır.
