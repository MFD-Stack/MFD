package com.mfd.assistant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

/**
 * MFD - Mehmet Fatih DURSUN
 * Ana Ekran
 */
public class MainActivity extends AppCompatActivity {

    private static final int RC_PERMS = 100;

    // UI
    private OrbView orbView;
    private TextView tvStatus, tvTime, tvBattery, tvWeather, tvGreeting;
    private View statusDot;
    private FloatingActionButton btnMic;
    private ImageButton btnSend;
    private android.widget.EditText etInput;
    private RecyclerView chatLog;
    private ChatLogAdapter adapter;

    // Core
    private AppConfig cfg;
    private MemoryManager memory;
    private AndroidActions actions;
    private GeminiClient gemini;
    private TextToSpeech tts;
    private SpeechRecognizer sr;

    private boolean isListening = false;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Timer clockTimer;

    // Bildirim bekleme modu
    private boolean waitingApproval = false;
    private String pendingAction = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cfg = new AppConfig(this);
        if (!cfg.hasGeminiKey()) {
            startActivity(new Intent(this, SetupActivity.class));
            finish(); return;
        }

        setContentView(R.layout.activity_main);

        // Views
        orbView    = findViewById(R.id.orbView);
        tvStatus   = findViewById(R.id.tvStatus);
        tvTime     = findViewById(R.id.tvTime);
        tvBattery  = findViewById(R.id.tvBattery);
        tvWeather  = findViewById(R.id.tvWeather);
        tvGreeting = findViewById(R.id.tvGreeting);
        statusDot  = findViewById(R.id.statusDot);
        btnMic     = findViewById(R.id.btnMic);
        btnSend    = findViewById(R.id.btnSend);
        etInput    = findViewById(R.id.etInput);
        chatLog    = findViewById(R.id.chatLog);

        // RecyclerView
        adapter = new ChatLogAdapter();
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        chatLog.setLayoutManager(llm);
        chatLog.setAdapter(adapter);

        // Greeting
        String name = cfg.getUserName();
        tvGreeting.setText(name.isEmpty() ? "Merhaba" : "Merhaba, " + name);

        // Core
        memory  = new MemoryManager(this);
        actions = new AndroidActions(this);
        gemini  = new GeminiClient(cfg.getGeminiKey(), getSharedPreferences("mfd_config", MODE_PRIVATE).getString("working_model", "gemini-2.5-flash-preview-05-20"),
                GeminiClient.buildSystemPrompt(cfg.getUserName(), memory.toPromptString()),
                GeminiClient.buildToolDeclarations());

        // TTS
        initTTS();

        // Speech
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            sr = SpeechRecognizer.createSpeechRecognizer(this);
            sr.setRecognitionListener(new MFDRecognitionListener());
        }

        // Listeners
        btnMic.setOnClickListener(v -> toggleMic());
        btnSend.setOnClickListener(v -> submitText());
        etInput.setOnEditorActionListener((v, id, event) -> {
            if (id == EditorInfo.IME_ACTION_SEND ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                            && event.getAction() == KeyEvent.ACTION_DOWN)) {
                submitText(); return true;
            }
            return false;
        });

        // Bildirim dinleyici
        setupNotificationListener();

        startClock();
        requestPerms();
        setState(OrbView.State.LISTENING);
        log(ChatLogAdapter.sys("MFD hazır. Komut bekliyorum..."));
        loadInfoCards();
    }

    // ── TTS ───────────────────────────────────────────────────────────────────

    private void initTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("tr", "TR"));
                if (r < 0) tts.setLanguage(Locale.ENGLISH);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { ui.post(() -> setState(OrbView.State.SPEAKING)); }
                    @Override public void onDone(String id)  { ui.post(() -> setState(OrbView.State.LISTENING)); }
                    @Override public void onError(String id) { ui.post(() -> setState(OrbView.State.LISTENING)); }
                });
            }
        });
    }

    private void speak(String text) {
        if (tts != null && !TextUtils.isEmpty(text)) {
            Bundle p = new Bundle();
            String uid = "mfd_" + System.currentTimeMillis();
            p.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, uid);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, p, uid);
        }
    }

    // ── MIC ───────────────────────────────────────────────────────────────────

    private void toggleMic() {
        if (isListening) { isListening = false; if (sr!=null) sr.stopListening(); return; }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this,"Mikrofon izni gerekiyor.",Toast.LENGTH_SHORT).show(); return;
        }
        if (sr == null) { Toast.makeText(this,"Ses tanıma yok.",Toast.LENGTH_SHORT).show(); return; }
        isListening = true;
        setState(OrbView.State.LISTENING);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        sr.startListening(i);
    }

    // ── TEXT INPUT ────────────────────────────────────────────────────────────

    private void submitText() {
        if (etInput.getText() == null) return;
        String t = etInput.getText().toString().trim();
        if (t.isEmpty()) return;
        etInput.setText("");
        process(t);
    }

    // ── PIPELINE ──────────────────────────────────────────────────────────────

    private void process(String text) {
        log(ChatLogAdapter.user(text));
        setState(OrbView.State.THINKING);

        gemini.sendMessage(text, new GeminiClient.Callback() {
            @Override public void onResponse(String resp, JSONArray tools) {
                ui.post(() -> handleResponse(resp, tools));
            }
            @Override public void onError(String err) {
                ui.post(() -> {
                    log(ChatLogAdapter.err(err));
                    setState(OrbView.State.ERROR);
                    ui.postDelayed(() -> setState(OrbView.State.LISTENING), 4000);
                });
            }
        });
    }

    private void handleResponse(String text, JSONArray tools) {
        if (tools != null && tools.length() > 0) {
            runTools(tools); return;
        }
        if (!TextUtils.isEmpty(text)) {
            log(ChatLogAdapter.mfd(text));
            speak(text);
        }
        setState(OrbView.State.LISTENING);
    }

    private void runTools(JSONArray tools) {
        setState(OrbView.State.THINKING);
        new Thread(() -> {
            try {
                JSONObject call = tools.getJSONObject(0);
                String name = call.optString("name");
                JSONObject args = call.optJSONObject("args");
                if (args == null) args = new JSONObject();
                final JSONObject a = args;

                // Onay gerektiren eylemler
                if (needsApproval(name)) {
                    String preview = buildApprovalMessage(name, args);
                    final String finalName = name;
                    final JSONObject finalArgs = args;
                    ui.post(() -> showApprovalDialog(preview, () -> {
                        new Thread(() -> executeAndContinue(finalName, finalArgs, tools)).start();
                    }));
                    return;
                }

                executeAndContinue(name, a, tools);
            } catch (Exception e) {
                ui.post(() -> {
                    log(ChatLogAdapter.err("Tool hatası: " + e.getMessage()));
                    setState(OrbView.State.LISTENING);
                });
            }
        }).start();
    }

    private boolean needsApproval(String name) {
        return name.equals("send_whatsapp") || name.equals("send_sms")
                || name.equals("add_calendar_event") || name.equals("delete_calendar_event");
    }

    private String buildApprovalMessage(String name, JSONObject args) {
        try {
            switch (name) {
                case "send_whatsapp":
                    return "WhatsApp mesajı gönderilsin mi?\nKişi: " + args.optString("phone_or_name")
                            + "\nMesaj: " + args.optString("message");
                case "send_sms":
                    return "SMS gönderilsin mi?\nNumara: " + args.optString("phone")
                            + "\nMesaj: " + args.optString("message");
                case "add_calendar_event":
                    return "Takvime eklensin mi?\nEtkinlik: " + args.optString("title")
                            + "\nTarih: " + args.optString("start_iso");
                case "delete_calendar_event":
                    return "Takvimden silinsin mi?\nEtkinlik: " + args.optString("title");
                default: return name + " çalıştırılsın mı?";
            }
        } catch (Exception e) { return name + " çalıştırılsın mı?"; }
    }

    private void showApprovalDialog(String msg, Runnable onYes) {
        new AlertDialog.Builder(this)
                .setTitle("Onay Gerekiyor")
                .setMessage(msg)
                .setPositiveButton("Evet, Yap", (d, w) -> onYes.run())
                .setNegativeButton("Hayır, İptal", (d, w) -> {
                    log(ChatLogAdapter.sys("İşlem iptal edildi."));
                    setState(OrbView.State.LISTENING);
                })
                .show();
    }

    private void executeAndContinue(String name, JSONObject args, JSONArray allTools) {
        String result = executeTool(name, args);
        ui.post(() -> log(ChatLogAdapter.tool(name, result)));

        gemini.sendToolResult(name, result, new GeminiClient.Callback() {
            @Override public void onResponse(String resp, JSONArray next) {
                ui.post(() -> {
                    if (next != null && next.length() > 0) { runTools(next); return; }
                    if (!TextUtils.isEmpty(resp)) { log(ChatLogAdapter.mfd(resp)); speak(resp); }
                    setState(OrbView.State.LISTENING);
                });
            }
            @Override public void onError(String err) {
                ui.post(() -> {
                    log(ChatLogAdapter.err(err));
                    setState(OrbView.State.ERROR);
                    ui.postDelayed(() -> setState(OrbView.State.LISTENING), 4000);
                });
            }
        });
    }

    private String executeTool(String name, JSONObject a) {
        try {
            switch (name) {
                case "open_app":           return actions.openApp(a.optString("app_name",""));
                case "sys_info":           return actions.sysInfo(a.optString("query","all"));
                case "get_weather":        return actions.getWeather(a.optString("location",""));
                case "get_calendar_events":return actions.getCalendarEvents(a.optString("query","today"),a.optInt("limit",6));
                case "add_calendar_event": return actions.addCalendarEvent(a.optString("title",""),a.optString("start_iso",""),a.optString("end_iso",""),a.optString("notes",""),a.optString("location",""),a.optBoolean("all_day",false));
                case "delete_calendar_event":return actions.deleteCalendarEvent(a.optString("title",""));
                case "get_reminders":      return actions.getReminders(a.optString("query","all"),a.optInt("limit",8));
                case "add_reminder":       return actions.addReminder(a.optString("title",""),a.optString("due_iso",""),a.optString("notes",""));
                case "browser_control":    return actions.browserControl(a.optString("action","search"),a.optString("url",""),a.optString("query",""));
                case "play_media":         return actions.playMedia(a.optString("query",""),a.optString("provider","auto"));
                case "send_whatsapp":      return actions.sendWhatsApp(a.optString("phone_or_name",""),a.optString("message",""));
                case "send_sms":           return actions.sendSms(a.optString("phone",""),a.optString("message",""));
                case "save_memory":        memory.save(a.optString("category","notes"),a.optString("key","item"),a.optString("value","")); return "ok";
                case "delete_memory":      return memory.delete(a.optString("category",""),a.optString("key",""),a.optString("match_text",""));
                default:                   return "Bilinmeyen araç: " + name;
            }
        } catch (Exception e) { return "Hata: " + e.getMessage(); }
    }

    // ── BİLDİRİM DİNLEYİCİ ───────────────────────────────────────────────────

    private void setupNotificationListener() {
        MFDNotificationListener.callback = (app, title, text) -> {
            // Kullanıcıya bildirim göster ve yanıt vermek isteyip istemediğini sor
            ui.post(() -> {
                String msg = "[" + app + "] " + title + ": " + text;
                log(ChatLogAdapter.sys("📩 " + msg));
                // MFD'ye bildirim bilgisi ilet
                String prompt = app + " üzerinden " + title + " sana mesaj gönderdi: \"" + text
                        + "\". Yanıt vermemi ister misin?";
                process(prompt);
            });
        };
    }

    // ── UI HELPERS ────────────────────────────────────────────────────────────

    private void setState(OrbView.State state) {
        orbView.setState(state);
        switch (state) {
            case LISTENING: tvStatus.setText("DİNLİYORUM"); statusDot.setBackgroundResource(R.drawable.circle_green); break;
            case SPEAKING:  tvStatus.setText("KONUŞUYOR");  statusDot.setBackgroundColor(Color.parseColor("#4488FF")); break;
            case THINKING:  tvStatus.setText("DÜŞÜNÜYOR");  statusDot.setBackgroundColor(Color.parseColor("#FFCC00")); break;
            case ERROR:     tvStatus.setText("HATA");        statusDot.setBackgroundColor(Color.parseColor("#FF3344")); break;
            default:        tvStatus.setText("—");
        }
    }

    private void log(ChatLogAdapter.Entry e) {
        adapter.add(e);
        chatLog.scrollToPosition(adapter.getItemCount()-1);
    }

    // ── CLOCK ─────────────────────────────────────────────────────────────────

    private void startClock() {
        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.getDefault());
        clockTimer = new Timer();
        clockTimer.scheduleAtFixedRate(new TimerTask() {
            @Override public void run() { ui.post(() -> tvTime.setText(fmt.format(new Date()))); }
        }, 0, 30000);
    }

    // ── INFO CARDS ────────────────────────────────────────────────────────────

    private void loadInfoCards() {
        new Thread(() -> {
            String batt = actions.sysInfo("battery").replace("Pil: ","").trim();
            if (batt.length()>20) batt = batt.substring(0,20);
            final String b = batt;
            ui.post(() -> tvBattery.setText(b));

            String w = actions.getWeather(null);
            int ci = w.indexOf(": ");
            if (ci>=0) w = w.substring(ci+2);
            if (w.length()>22) w = w.substring(0,22)+"…";
            final String wf = w;
            ui.post(() -> tvWeather.setText(wf));
        }).start();
    }

    // ── PERMISSIONS ───────────────────────────────────────────────────────────

    private void requestPerms() {
        ArrayList<String> needed = new ArrayList<>();
        String[] perms = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CALENDAR,
                Manifest.permission.WRITE_CALENDAR, Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS};
        for (String p : perms)
            if (ContextCompat.checkSelfPermission(this,p) != PackageManager.PERMISSION_GRANTED) needed.add(p);
        if (!needed.isEmpty())
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), RC_PERMS);
    }

    // ── RECOGNITION LISTENER ──────────────────────────────────────────────────

    private class MFDRecognitionListener implements RecognitionListener {
        @Override public void onReadyForSpeech(Bundle p) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float v) {}
        @Override public void onBufferReceived(byte[] b) {}
        @Override public void onEndOfSpeech() { isListening=false; ui.post(()->setState(OrbView.State.THINKING)); }
        @Override public void onError(int e) { isListening=false; ui.post(()->setState(OrbView.State.LISTENING)); }
        @Override public void onResults(Bundle results) {
            ArrayList<String> m = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (m!=null&&!m.isEmpty()) ui.post(()->process(m.get(0)));
            else ui.post(()->setState(OrbView.State.LISTENING));
        }
        @Override public void onPartialResults(Bundle b) {}
        @Override public void onEvent(int t, Bundle b) {}
    }

    // ── LIFECYCLE ─────────────────────────────────────────────────────────────

    @Override protected void onDestroy() {
        super.onDestroy();
        if (tts!=null)       { tts.stop(); tts.shutdown(); }
        if (sr!=null)          sr.destroy();
        if (clockTimer!=null)  clockTimer.cancel();
        MFDNotificationListener.callback = null;
    }
}
