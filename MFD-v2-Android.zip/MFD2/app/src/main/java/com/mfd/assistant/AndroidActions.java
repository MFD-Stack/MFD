package com.mfd.assistant;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.CalendarContract.Events;
import android.provider.CalendarContract.Instances;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

/**
 * MFD - Mehmet Fatih DURSUN
 * Android Actions — tüm sistem eylemleri
 */
public class AndroidActions {

    private final Context ctx;

    public AndroidActions(Context ctx) { this.ctx = ctx.getApplicationContext(); }

    // ── SYS INFO ─────────────────────────────────────────────────────────────

    public String sysInfo(String query) {
        if (query == null) query = "all";
        query = query.toLowerCase().trim();
        List<String> r = new ArrayList<>();
        if (query.contains("battery") || query.contains("pil") || query.equals("all")) r.add(getBattery());
        if (query.contains("ram") || query.contains("bellek") || query.equals("all"))  r.add(getRam());
        if (query.contains("disk") || query.contains("storage") || query.equals("all")) r.add(getDisk());
        if (query.contains("time") || query.contains("saat") || query.equals("all"))
            r.add("Saat: " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
        if (query.contains("date") || query.contains("tarih") || query.equals("all"))
            r.add("Tarih: " + new SimpleDateFormat("dd MMMM yyyy, EEEE", new Locale("tr")).format(new Date()));
        if (query.contains("network") || query.contains("ağ") || query.equals("all")) r.add(getNetwork());
        if (r.isEmpty()) r.add("Bilinmeyen sorgu: " + query);
        StringBuilder sb = new StringBuilder();
        for (String s : r) sb.append(s).append("\n");
        return sb.toString().trim();
    }

    private String getBattery() {
        try {
            Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i == null) return "Pil: —";
            int lvl    = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale  = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean ch = status == BatteryManager.BATTERY_STATUS_CHARGING
                      || status == BatteryManager.BATTERY_STATUS_FULL;
            return String.format(Locale.getDefault(), "Pil: %.0f%% — %s",
                    (lvl / (float) scale) * 100, ch ? "Şarj oluyor" : "Pilde");
        } catch (Exception e) { return "Pil: bilgi alınamadı"; }
    }

    private String getRam() {
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long total = mi.totalMem / (1024*1024);
            long avail = mi.availMem / (1024*1024);
            return String.format(Locale.getDefault(), "RAM: %dMB / %dMB kullanımda", total-avail, total);
        } catch (Exception e) { return "RAM: bilgi alınamadı"; }
    }

    private String getDisk() {
        try {
            android.os.StatFs s = new android.os.StatFs(android.os.Environment.getDataDirectory().getPath());
            long bs = s.getBlockSizeLong();
            long total = s.getBlockCountLong() * bs / (1024L*1024*1024);
            long avail = s.getAvailableBlocksLong() * bs / (1024L*1024*1024);
            return String.format(Locale.getDefault(), "Disk: %dGB boş / %dGB toplam", avail, total);
        } catch (Exception e) { return "Disk: bilgi alınamadı"; }
    }

    private String getNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) return "Ağ: " + ni.getTypeName() + " bağlı";
        } catch (Exception ignored) {}
        return "Ağ: bağlantı yok";
    }

    // ── WEATHER ──────────────────────────────────────────────────────────────

    public String getWeather(String location) {
        if (location == null || location.isEmpty())
            location = new AppConfig(ctx).getLocation();
        try {
            URL url = new URL("https://wttr.in/" + Uri.encode(location) + "?format=j1");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", "MFD-Android/2.0");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder(); String l;
            while ((l = br.readLine()) != null) sb.append(l); br.close();
            JSONObject j = new JSONObject(sb.toString());
            JSONObject cur = j.getJSONArray("current_condition").getJSONObject(0);
            String temp = cur.optString("temp_C","?");
            String feel = cur.optString("FeelsLikeC","?");
            String desc = cur.getJSONArray("weatherDesc").getJSONObject(0).optString("value","");
            String hum  = cur.optString("humidity","?");
            return location + ": " + temp + "°C, " + desc.toLowerCase()
                    + ", hissedilen " + feel + "°C, nem %" + hum;
        } catch (Exception e) { return "Hava durumu alınamadı: " + e.getMessage(); }
    }

    // ── CALENDAR ─────────────────────────────────────────────────────────────

    public String getCalendarEvents(String query, int limit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR)
                != PackageManager.PERMISSION_GRANTED) return "Takvim izni gerekiyor.";
        try {
            long now = System.currentTimeMillis(), start = now, end;
            String q = query == null ? "" : query.toLowerCase();
            if (q.contains("bugün") || q.contains("today")) {
                Calendar c = Calendar.getInstance();
                c.set(Calendar.HOUR_OF_DAY,23); c.set(Calendar.MINUTE,59); end = c.getTimeInMillis();
            } else if (q.contains("yarın") || q.contains("tomorrow")) {
                Calendar c = Calendar.getInstance(); c.add(Calendar.DAY_OF_YEAR,1);
                c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); start = c.getTimeInMillis();
                c.set(Calendar.HOUR_OF_DAY,23); c.set(Calendar.MINUTE,59); end = c.getTimeInMillis();
            } else if (q.contains("hafta") || q.contains("week")) {
                end = now + 7L*24*3600*1000;
            } else { end = now + 30L*24*3600*1000; }
            Uri.Builder b = Instances.CONTENT_URI.buildUpon();
            android.content.ContentUris.appendId(b, start);
            android.content.ContentUris.appendId(b, end);
            Cursor c = ctx.getContentResolver().query(b.build(),
                    new String[]{Instances.TITLE, Instances.BEGIN, Instances.EVENT_LOCATION},
                    null, null, Instances.START_DAY + " ASC");
            if (c == null) return "Takvim alınamadı.";
            List<String> ev = new ArrayList<>();
            SimpleDateFormat sdf = new SimpleDateFormat("d MMM HH:mm", new Locale("tr"));
            while (c.moveToNext() && ev.size() < limit) {
                String entry = sdf.format(new Date(c.getLong(1))) + " — " + c.getString(0);
                String loc = c.getString(2);
                if (loc != null && !loc.isEmpty()) entry += " (" + loc + ")";
                ev.add(entry);
            }
            c.close();
            if (ev.isEmpty()) return "Etkinlik bulunamadı.";
            return "Takvim:\n" + android.text.TextUtils.join("\n", ev);
        } catch (Exception e) { return "Takvim hatası: " + e.getMessage(); }
    }

    public String addCalendarEvent(String title, String startIso, String endIso,
                                    String notes, String location, boolean allDay) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR)
                != PackageManager.PERMISSION_GRANTED) return "Takvim yazma izni gerekiyor.";
        try {
            long calId = getFirstCalendarId();
            if (calId < 0) return "Takvim bulunamadı.";
            long sMs = parseIso(startIso);
            long eMs = (endIso != null && !endIso.isEmpty()) ? parseIso(endIso) : sMs + 3600000L;
            ContentValues v = new ContentValues();
            v.put(Events.CALENDAR_ID, calId);
            v.put(Events.TITLE, title);
            v.put(Events.DTSTART, sMs);
            v.put(Events.DTEND, eMs);
            v.put(Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
            if (notes    != null && !notes.isEmpty())    v.put(Events.DESCRIPTION, notes);
            if (location != null && !location.isEmpty()) v.put(Events.EVENT_LOCATION, location);
            if (allDay) v.put(Events.ALL_DAY, 1);
            Uri uri = ctx.getContentResolver().insert(Events.CONTENT_URI, v);
            return uri != null ? "Etkinlik eklendi: " + title : "Eklenemedi.";
        } catch (Exception e) { return "Hata: " + e.getMessage(); }
    }

    public String deleteCalendarEvent(String title) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_CALENDAR)
                != PackageManager.PERMISSION_GRANTED) return "İzin gerekiyor.";
        try {
            int rows = ctx.getContentResolver().delete(Events.CONTENT_URI,
                    Events.TITLE + " = ?", new String[]{title});
            return rows > 0 ? rows + " etkinlik silindi." : "Bulunamadı: " + title;
        } catch (Exception e) { return "Hata: " + e.getMessage(); }
    }

    private long getFirstCalendarId() {
        Cursor c = ctx.getContentResolver().query(
                CalendarContract.Calendars.CONTENT_URI,
                new String[]{CalendarContract.Calendars._ID}, null, null, null);
        if (c != null && c.moveToFirst()) { long id = c.getLong(0); c.close(); return id; }
        if (c != null) c.close(); return -1;
    }

    // ── REMINDERS ────────────────────────────────────────────────────────────

    public String getReminders(String query, int limit) {
        MemoryManager mm = new MemoryManager(ctx);
        JSONObject mem = mm.load();
        JSONObject rem = mem.optJSONObject("reminders");
        if (rem == null || rem.length() == 0) return "Anımsatıcı yok.";
        StringBuilder sb = new StringBuilder("Anımsatıcılar:\n");
        Iterator<String> it = rem.keys(); int n = 0;
        while (it.hasNext() && n < limit) {
            String k = it.next();
            sb.append("- ").append(rem.optString(k, k)).append("\n"); n++;
        }
        return sb.toString().trim();
    }

    public String addReminder(String title, String dueIso, String notes) {
        MemoryManager mm = new MemoryManager(ctx);
        String val = title;
        if (dueIso != null && !dueIso.isEmpty()) val += " — " + dueIso;
        if (notes  != null && !notes.isEmpty())  val += " [" + notes + "]";
        mm.save("reminders", title.replaceAll("\\s+","_").toLowerCase(), val);
        if (dueIso != null && !dueIso.isEmpty()) {
            try {
                long ms = parseIso(dueIso);
                Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
                i.putExtra(AlarmClock.EXTRA_MESSAGE, title);
                i.putExtra(AlarmClock.EXTRA_HOUR, getHour(ms));
                i.putExtra(AlarmClock.EXTRA_MINUTES, getMin(ms));
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(i);
            } catch (Exception ignored) {}
        }
        return "Anımsatıcı eklendi: " + title;
    }

    // ── BROWSER ──────────────────────────────────────────────────────────────

    public String browserControl(String action, String url, String query) {
        try {
            Intent intent;
            if ("open_url".equals(action) && url != null && !url.isEmpty()) {
                intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            } else if ("play_youtube".equals(action)) {
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query != null ? query : "")));
            } else {
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.google.com/search?q=" + Uri.encode(query != null ? query : "")));
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return "Tarayıcı açıldı.";
        } catch (Exception e) { return "Tarayıcı açılamadı: " + e.getMessage(); }
    }

    // ── MEDIA ────────────────────────────────────────────────────────────────

    public String playMedia(String query, String provider) {
        try {
            Intent intent;
            if ("spotify".equalsIgnoreCase(provider)) {
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("spotify:search:" + Uri.encode(query != null ? query : "")));
                intent.setPackage("com.spotify.music");
            } else {
                intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query != null ? query : "")));
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return "Oynatılıyor: " + query;
        } catch (Exception e) { return "Medya açılamadı: " + e.getMessage(); }
    }

    // ── WHATSAPP ─────────────────────────────────────────────────────────────

    public String sendWhatsApp(String phoneOrName, String message) {
        try {
            // Normalize phone number
            String phone = phoneOrName.replaceAll("[^0-9+]", "");
            if (phone.isEmpty()) {
                // Try to open WhatsApp with contact name via share
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.setPackage("com.whatsapp");
                intent.putExtra(Intent.EXTRA_TEXT, message);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "WhatsApp açıldı, mesaj hazırlandı: " + message;
            }
            // Direct message with phone number
            if (!phone.startsWith("+")) phone = "+90" + phone; // Turkey default
            Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=" + phone
                    + "&text=" + Uri.encode(message));
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.setPackage("com.whatsapp");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
            return "WhatsApp mesajı hazırlandı: " + phoneOrName + " → " + message;
        } catch (Exception e) { return "WhatsApp açılamadı: " + e.getMessage(); }
    }

    // ── SMS ──────────────────────────────────────────────────────────────────

    public String sendSms(String phone, String message) {
        try {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Open SMS app instead
                Intent intent = new Intent(Intent.ACTION_SENDTO,
                        Uri.parse("smsto:" + phone));
                intent.putExtra("sms_body", message);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "SMS uygulaması açıldı.";
            }
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            return "SMS gönderildi: " + phone;
        } catch (Exception e) { return "SMS gönderilemedi: " + e.getMessage(); }
    }

    // ── OPEN APP ─────────────────────────────────────────────────────────────

    public String openApp(String name) {
        if (name == null || name.isEmpty()) return "Uygulama adı belirtilmedi.";
        String pkg = resolvePackage(name.toLowerCase());
        if (pkg != null) {
            Intent li = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
            if (li != null) {
                li.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(li);
                return name + " açıldı.";
            }
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://search?q=" + Uri.encode(name)));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            return name + " Play Store'da aranıyor.";
        } catch (Exception e) { return name + " bulunamadı."; }
    }

    private String resolvePackage(String n) {
        if (n.contains("spotify"))   return "com.spotify.music";
        if (n.contains("youtube"))   return "com.google.android.youtube";
        if (n.contains("chrome"))    return "com.android.chrome";
        if (n.contains("whatsapp"))  return "com.whatsapp";
        if (n.contains("instagram")) return "com.instagram.android";
        if (n.contains("twitter") || n.equals("x")) return "com.twitter.android";
        if (n.contains("telegram"))  return "org.telegram.messenger";
        if (n.contains("gmail"))     return "com.google.android.gm";
        if (n.contains("harita") || n.contains("maps")) return "com.google.android.apps.maps";
        if (n.contains("ayarlar") || n.contains("settings")) return "com.android.settings";
        if (n.contains("telefon") || n.contains("phone")) return "com.android.dialer";
        if (n.contains("hesap") || n.contains("calculator")) return "com.android.calculator2";
        if (n.contains("saat") || n.contains("clock")) return "com.android.deskclock";
        if (n.contains("netflix"))   return "com.netflix.mediaclient";
        if (n.contains("tiktok"))    return "com.zhiliaoapp.musically";
        if (n.contains("discord"))   return "com.discord";
        if (n.contains("kamera") || n.contains("camera")) return "com.android.camera2";
        if (n.contains("müzik") || n.contains("music")) return "com.google.android.music";
        if (n.contains("dosya") || n.contains("files")) return "com.google.android.apps.nbu.files";
        return null;
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private long parseIso(String iso) {
        if (iso == null || iso.isEmpty()) return System.currentTimeMillis();
        String[] fmts = {"yyyy-MM-dd'T'HH:mm:ss","yyyy-MM-dd'T'HH:mm","yyyy-MM-dd HH:mm","yyyy-MM-dd"};
        for (String f : fmts) {
            try {
                SimpleDateFormat s = new SimpleDateFormat(f, Locale.getDefault());
                s.setTimeZone(TimeZone.getDefault());
                Date d = s.parse(iso);
                if (d != null) return d.getTime();
            } catch (Exception ignored) {}
        }
        return System.currentTimeMillis();
    }

    private int getHour(long ms) { Calendar c = Calendar.getInstance(); c.setTimeInMillis(ms); return c.get(Calendar.HOUR_OF_DAY); }
    private int getMin(long ms)  { Calendar c = Calendar.getInstance(); c.setTimeInMillis(ms); return c.get(Calendar.MINUTE); }
}
