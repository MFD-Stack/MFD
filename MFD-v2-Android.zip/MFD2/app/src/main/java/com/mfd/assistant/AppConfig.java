package com.mfd.assistant;

import android.content.Context;
import android.content.SharedPreferences;

public class AppConfig {
    private static final String PREF = "mfd_config";
    private final SharedPreferences p;

    public AppConfig(Context ctx) { p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public String getGeminiKey()     { return p.getString("gemini_key", ""); }
    public boolean hasGeminiKey()    { return !getGeminiKey().isEmpty(); }
    public String getLocation()      { return p.getString("location", "Istanbul"); }
    public String getUserName()      { return p.getString("user_name", ""); }

    public void saveAll(String key, String location, String userName) {
        p.edit()
         .putString("gemini_key", key.trim())
         .putString("location", location.isEmpty() ? "Istanbul" : location)
         .putString("user_name", userName)
         .apply();
    }
}
