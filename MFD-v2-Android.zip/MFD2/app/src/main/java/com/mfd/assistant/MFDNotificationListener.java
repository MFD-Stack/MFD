package com.mfd.assistant;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/**
 * MFD - Mehmet Fatih DURSUN
 * Bildirim Dinleyici — WhatsApp ve diğer uygulamalardan gelen bildirimleri alır
 */
public class MFDNotificationListener extends NotificationListenerService {

    public static MFDNotificationListener instance;
    public static NotificationCallback callback;

    public interface NotificationCallback {
        void onNotification(String app, String title, String text);
    }

    @Override
    public void onCreate() { super.onCreate(); instance = this; }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (callback == null) return;
        String pkg = sbn.getPackageName();

        // Sadece ilgili uygulamaları dinle
        if (!pkg.contains("whatsapp") && !pkg.contains("telegram")
                && !pkg.contains("instagram") && !pkg.contains("twitter")
                && !pkg.contains("messaging") && !pkg.contains("sms")) return;

        Notification n = sbn.getNotification();
        Bundle extras = n.extras;
        String title = extras.getString(Notification.EXTRA_TITLE, "");
        String text  = extras.getString(Notification.EXTRA_TEXT, "");

        if (text == null || text.isEmpty()) return;

        String appName;
        if (pkg.contains("whatsapp"))  appName = "WhatsApp";
        else if (pkg.contains("telegram")) appName = "Telegram";
        else if (pkg.contains("instagram")) appName = "Instagram";
        else appName = pkg;

        callback.onNotification(appName, title, text);
    }

    @Override
    public void onListenerConnected() { super.onListenerConnected(); instance = this; }
}
