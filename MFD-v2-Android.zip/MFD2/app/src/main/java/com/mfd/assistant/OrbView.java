package com.mfd.assistant;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.LinearInterpolator;

/**
 * MFD - Mehmet Fatih DURSUN
 * Animated HUD Orb
 */
public class OrbView extends View {

    public enum State { LISTENING, SPEAKING, THINKING, ERROR, MUTED }

    private static final int[][] COLORS = {
            {0, 255, 136},   // LISTENING — yeşil
            {68, 136, 255},  // SPEAKING  — mavi
            {255, 204, 0},   // THINKING  — altın
            {255, 51, 68},   // ERROR     — kırmızı
            {200, 30, 80},   // MUTED     — mor
    };

    private State state = State.LISTENING;
    private float rotation = 0f;
    private float pulse    = 0.5f;

    private final Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotP  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txtP  = new Paint(Paint.ANTI_ALIAS_FLAG);

    private ValueAnimator rotAnim, pulseAnim;

    public OrbView(Context ctx) { super(ctx); init(); }
    public OrbView(Context ctx, AttributeSet a) { super(ctx, a); init(); }

    private void init() {
        ringP.setStyle(Paint.Style.STROKE); ringP.setStrokeWidth(2.5f);
        arcP.setStyle(Paint.Style.STROKE);  arcP.setStrokeWidth(5f); arcP.setStrokeCap(Paint.Cap.ROUND);
        glowP.setStyle(Paint.Style.FILL);
        dotP.setStyle(Paint.Style.FILL);
        txtP.setTextAlign(Paint.Align.CENTER); txtP.setLetterSpacing(0.2f);

        rotAnim = ValueAnimator.ofFloat(0f, 360f);
        rotAnim.setDuration(7000);
        rotAnim.setInterpolator(new LinearInterpolator());
        rotAnim.setRepeatCount(ValueAnimator.INFINITE);
        rotAnim.addUpdateListener(a -> { rotation = (float) a.getAnimatedValue(); invalidate(); });

        pulseAnim = ValueAnimator.ofFloat(0.3f, 1f);
        pulseAnim.setDuration(1600);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.setRepeatMode(ValueAnimator.REVERSE);
        pulseAnim.addUpdateListener(a -> { pulse = (float) a.getAnimatedValue(); invalidate(); });

        rotAnim.start(); pulseAnim.start();
    }

    public void setState(State s) { this.state = s; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float r  = Math.min(getWidth(), getHeight()) / 2f * 0.9f;
        int[] col = COLORS[state.ordinal()];
        int R = col[0], G = col[1], B = col[2];

        // Glow
        glowP.setColor(Color.argb((int)(pulse * 70), R, G, B));
        canvas.drawCircle(cx, cy, r * 0.30f, glowP);
        glowP.setColor(Color.argb((int)(pulse * 40), R, G, B));
        canvas.drawCircle(cx, cy, r * 0.50f, glowP);

        // Inner ring
        ringP.setColor(Color.argb(100, R/3, G/3, B/3));
        canvas.drawCircle(cx, cy, r * 0.35f, ringP);

        // Mid ring
        ringP.setColor(Color.argb(60, R, G, B));
        canvas.drawCircle(cx, cy, r * 0.55f, ringP);

        // Outer ring
        ringP.setColor(Color.argb(200, R, G, B));
        ringP.setStrokeWidth(2.5f);
        canvas.drawCircle(cx, cy, r * 0.88f, ringP);

        // Rotating arcs
        float arcR = r * 0.70f;
        RectF rf = new RectF(cx - arcR, cy - arcR, cx + arcR, cy + arcR);
        float[] starts = {0,45,90,135,180,225,270,315};
        for (int i = 0; i < starts.length; i++) {
            arcP.setColor(Color.argb(i%2==0?220:120, R, G, B));
            canvas.drawArc(rf, starts[i] + rotation, 28f, false, arcP);
        }

        // Dots
        float dotR = r * 0.92f;
        dotP.setColor(Color.argb(160, R, G, B));
        for (int i = 0; i < 12; i++) {
            double ang = Math.toRadians(i * 30 + rotation * 0.4);
            canvas.drawCircle(cx + (float)(dotR*Math.cos(ang)), cy + (float)(dotR*Math.sin(ang)),
                    i % 3 == 0 ? 4f : 2f, dotP);
        }

        // Label
        txtP.setColor(Color.argb(220, R, G, B));
        txtP.setTextSize(r * 0.16f);
        canvas.drawText(label(), cx, cy + txtP.getTextSize()/3, txtP);

        // Badge
        txtP.setColor(Color.argb(80, R, G, B));
        txtP.setTextSize(r * 0.09f);
        canvas.drawText("M.F.D", cx, cy - r * 0.13f, txtP);
    }

    private String label() {
        switch (state) {
            case LISTENING: return "DİNLİYORUM";
            case SPEAKING:  return "KONUŞUYOR";
            case THINKING:  return "DÜŞÜNÜYOR";
            case ERROR:     return "HATA";
            case MUTED:     return "SESSİZ";
            default:        return "";
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        rotAnim.cancel(); pulseAnim.cancel();
    }
}
