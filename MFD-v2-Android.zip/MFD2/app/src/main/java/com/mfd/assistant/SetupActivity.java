package com.mfd.assistant;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SetupActivity extends AppCompatActivity {

    private TextView tvTestResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppConfig cfg = new AppConfig(this);
        if (cfg.hasGeminiKey()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_setup);

        EditText etKey  = findViewById(R.id.etGeminiKey);
        EditText etLoc  = findViewById(R.id.etLocation);
        EditText etName = findViewById(R.id.etUserName);
        Button   btnGo  = findViewById(R.id.btnSave);
        tvTestResult    = findViewById(R.id.tvTestResult);

        etKey.setText(cfg.getGeminiKey());
        etLoc.setText(cfg.getLocation());
        etName.setText(cfg.getUserName());

        // Test butonu
        Button btnTest = findViewById(R.id.btnTest);
        if (btnTest != null) {
            btnTest.setOnClickListener(v -> {
                String key = etKey.getText().toString().trim();
                if (key.isEmpty()) {
                    tvTestResult.setText("Önce API anahtarı gir!");
                    return;
                }
                tvTestResult.setText("Test ediliyor...");
                testApi(key);
            });
        }

        btnGo.setOnClickListener(v -> {
            String key  = etKey.getText().toString().trim();
            String loc  = etLoc.getText().toString().trim();
            String name = etName.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(this, "API anahtarı gerekli!", Toast.LENGTH_SHORT).show();
                return;
            }
            cfg.saveAll(key, loc, name);
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void testApi(String apiKey) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        exec.execute(() -> {
            String result;
            try {
                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);

                String body = "{\"contents\":[{\"role\":\"user\",\"parts\":[{\"text\":\"Merhaba, sadece 'Çalışıyorum!' de.\"}]}]}";
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body.getBytes("UTF-8"));
                }

                int code = conn.getResponseCode();
                BufferedReader br;
                if (code == 200) {
                    br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                } else {
                    br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                    StringBuilder err = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) err.append(line);
                    br.close();
                    result = "HATA " + code + ": " + err.toString().substring(0, Math.min(200, err.length()));
                    final String r = result;
                    handler.post(() -> tvTestResult.setText(r));
                    return;
                }

                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();

                org.json.JSONObject resp = new org.json.JSONObject(sb.toString());
                String text = resp.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");

                result = "✅ BAŞARILI! Yanıt: " + text;

            } catch (Exception e) {
                result = "❌ HATA: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            }

            final String finalResult = result;
            handler.post(() -> tvTestResult.setText(finalResult));
        });
    }
}
