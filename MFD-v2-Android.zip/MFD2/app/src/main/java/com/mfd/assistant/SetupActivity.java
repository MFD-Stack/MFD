package com.mfd.assistant;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SetupActivity extends AppCompatActivity {

    private static final String[] MODELS = {
        "gemini-2.5-flash-preview-05-20",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-1.5-flash"
    };

    private TextView tvTestResult;
    private String workingModel = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppConfig cfg = new AppConfig(this);
        if (cfg.hasGeminiKey()) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_setup);

        EditText etKey  = findViewById(R.id.etGeminiKey);
        EditText etLoc  = findViewById(R.id.etLocation);
        EditText etName = findViewById(R.id.etUserName);
        Button   btnGo  = findViewById(R.id.btnSave);
        tvTestResult    = findViewById(R.id.tvTestResult);
        Button btnTest  = findViewById(R.id.btnTest);

        etKey.setText(cfg.getGeminiKey());
        etLoc.setText(cfg.getLocation());
        etName.setText(cfg.getUserName());

        btnTest.setOnClickListener(v -> {
            String key = etKey.getText().toString().trim();
            if (key.isEmpty()) {
                tvTestResult.setText("Önce API anahtarı gir!");
                return;
            }
            tvTestResult.setText("Modeller test ediliyor...");
            findWorkingModel(key);
        });

        btnGo.setOnClickListener(v -> {
            String key  = etKey.getText().toString().trim();
            String loc  = etLoc.getText().toString().trim();
            String name = etName.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(this, "API anahtarı gerekli!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (workingModel != null) {
                getSharedPreferences("mfd_config", MODE_PRIVATE)
                    .edit().putString("working_model", workingModel).apply();
            }
            cfg.saveAll(key, loc, name);
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    private void findWorkingModel(String apiKey) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        exec.execute(() -> {
            for (String model : MODELS) {
                handler.post(() -> tvTestResult.setText("⏳ Test: " + model + "..."));
                try {
                    String result = testModel(apiKey, model);
                    if (result.startsWith("OK:")) {
                        workingModel = model;
                        final String text = result.substring(3);
                        handler.post(() -> tvTestResult.setText(
                            "✅ Çalışıyor: " + model
                            + "\nYanıt: " + text
                            + "\n\nBAŞLAT'a basabilirsiniz!"));
                        return;
                    }
                    final String m = model, err = result;
                    handler.post(() -> tvTestResult.setText(
                        "❌ " + m + " → " + err + "\nSonraki deneniyor..."));
                    Thread.sleep(1500);
                } catch (Exception ignored) {}
            }
            handler.post(() -> tvTestResult.setText(
                "❌ Hiçbir model çalışmadı.\n"
                + "Yeni API anahtarı alın:\n"
                + "aistudio.google.com"));
        });
    }

    private String testModel(String apiKey, String model) {
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                + model + ":generateContent?key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);

            String body = "{\"contents\":[{\"role\":\"user\",\"parts\":"
                + "[{\"text\":\"Merhaba\"}]}],"
                + "\"generationConfig\":{\"maxOutputTokens\":20}}";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes("UTF-8"));
            }

            int code = conn.getResponseCode();
            StringBuilder sb = new StringBuilder();
            BufferedReader br;

            if (code == 200) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                JSONObject resp = new JSONObject(sb.toString());
                String text = resp.getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text");
                return "OK:" + text.trim();
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                try {
                    JSONObject ej = new JSONObject(sb.toString());
                    if (ej.has("error")) {
                        String msg = ej.getJSONObject("error").optString("message", "");
                        if (msg.length() > 60) msg = msg.substring(0, 60);
                        return "HATA " + code + ": " + msg;
                    }
                } catch (Exception ignored) {}
                return "HATA " + code;
            }
        } catch (Exception e) {
            return "HATA: " + e.getMessage();
        }
    }
}
