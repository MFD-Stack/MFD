package com.mfd.assistant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SetupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        AppConfig cfg = new AppConfig(this);
        if (cfg.hasGeminiKey()) {
            startActivity(new Intent(this, MainActivity.class));
            finish(); return;
        }

        setContentView(R.layout.activity_setup);

        EditText etKey  = findViewById(R.id.etGeminiKey);
        EditText etLoc  = findViewById(R.id.etLocation);
        EditText etName = findViewById(R.id.etUserName);
        Button   btnGo  = findViewById(R.id.btnSave);

        etKey.setText(cfg.getGeminiKey());
        etLoc.setText(cfg.getLocation());
        etName.setText(cfg.getUserName());

        btnGo.setOnClickListener(v -> {
            String key  = etKey.getText().toString().trim();
            String loc  = etLoc.getText().toString().trim();
            String name = etName.getText().toString().trim();
            if (key.isEmpty()) {
                Toast.makeText(this, "API anahtarı gerekli!", Toast.LENGTH_SHORT).show(); return;
            }
            cfg.saveAll(key, loc, name);
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }
}
