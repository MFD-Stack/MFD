package com.mfd.assistant;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class ChatLogAdapter extends RecyclerView.Adapter<ChatLogAdapter.VH> {

    public static class Entry {
        final String prefix, text;
        final int prefixColor, textColor;
        Entry(String p, String t, int pc, int tc) { prefix=p; text=t; prefixColor=pc; textColor=tc; }
    }

    private final List<Entry> entries = new ArrayList<>();

    public void add(Entry e) { entries.add(e); notifyItemInserted(entries.size()-1); }
    public void clear()       { entries.clear(); notifyDataSetChanged(); }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_log, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Entry e = entries.get(pos);
        h.prefix.setText(e.prefix); h.prefix.setTextColor(e.prefixColor);
        h.text.setText(e.text);     h.text.setTextColor(e.textColor);
    }

    @Override public int getItemCount() { return entries.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView prefix, text;
        VH(View v) { super(v); prefix=v.findViewById(R.id.tvLogPrefix); text=v.findViewById(R.id.tvLogText); }
    }

    public static Entry sys(String t)  { return new Entry("SYS", t, Color.parseColor("#006A62"), Color.parseColor("#0A2A28")); }
    public static Entry user(String t) { return new Entry("SİZ", t, Color.parseColor("#00D4C0"), Color.parseColor("#7DFFF6")); }
    public static Entry mfd(String t)  { return new Entry("MFD", t, Color.parseColor("#4488FF"), Color.parseColor("#AACCFF")); }
    public static Entry err(String t)  { return new Entry("ERR", t, Color.parseColor("#FF3344"), Color.parseColor("#FF8888")); }
    public static Entry tool(String n, String r) {
        return new Entry("🔧", n + " → " + (r.length()>80?r.substring(0,80)+"…":r),
                Color.parseColor("#FFCC00"), Color.parseColor("#FFF0AA"));
    }
}
