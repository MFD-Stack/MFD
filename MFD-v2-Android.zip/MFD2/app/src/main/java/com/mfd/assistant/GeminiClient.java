package com.mfd.assistant;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MFD - Mehmet Fatih DURSUN
 * Gemini 1.5 Flash REST Client
 */
public class GeminiClient {

    private static final String MODEL    = "gemini-1.5-flash";
    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"
            + MODEL + ":generateContent";

    public interface Callback {
        void onResponse(String text, JSONArray toolCalls);
        void onError(String error);
    }

    private final String apiKey;
    private final String systemPrompt;
    private final JSONArray toolDefs;
    private final JSONArray history = new JSONArray();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    public GeminiClient(String apiKey, String systemPrompt, JSONArray toolDefs) {
        this.apiKey       = apiKey;
        this.systemPrompt = systemPrompt;
        this.toolDefs     = toolDefs;
    }

    public void sendMessage(String text, Callback cb) {
        exec.execute(() -> {
            try {
                addToHistory("user", text);
                callApi(cb);
            } catch (Exception e) {
                cb.onError("Hata: " + e.getMessage());
            }
        });
    }

    public void sendToolResult(String name, String result, Callback cb) {
        exec.execute(() -> {
            try {
                JSONObject turn = new JSONObject();
                turn.put("role", "user");
                JSONArray parts = new JSONArray();
                parts.put(new JSONObject()
                        .put("functionResponse", new JSONObject()
                                .put("name", name)
                                .put("response", new JSONObject().put("result", result))));
                turn.put("parts", parts);
                history.put(turn);
                callApi(cb);
            } catch (Exception e) {
                cb.onError("Tool hatası: " + e.getMessage());
            }
        });
    }

    private void addToHistory(String role, String text) throws Exception {
        JSONObject turn = new JSONObject();
        turn.put("role", role);
        turn.put("parts", new JSONArray().put(new JSONObject().put("text", text)));
        history.put(turn);
    }

    private void callApi(Callback cb) {
        try {
            URL url = new URL(BASE_URL + "?key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(60000);

            // Build body
            JSONObject body = new JSONObject();
            body.put("systemInstruction", new JSONObject()
                    .put("parts", new JSONArray().put(new JSONObject().put("text", systemPrompt))));
            body.put("contents", history);
            if (toolDefs != null && toolDefs.length() > 0) {
                body.put("tools", new JSONArray()
                        .put(new JSONObject().put("functionDeclarations", toolDefs)));
            }
            body.put("generationConfig", new JSONObject()
                    .put("temperature", 0.7)
                    .put("maxOutputTokens", 1024));

            // Send
            byte[] data = body.toString().getBytes("UTF-8");
            conn.setRequestProperty("Content-Length", String.valueOf(data.length));
            try (OutputStream os = conn.getOutputStream()) { os.write(data); }

            // Read response
            int code = conn.getResponseCode();
            BufferedReader br;
            if (code == 200) {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
                StringBuilder err = new StringBuilder();
                String l; while ((l = br.readLine()) != null) err.append(l);
                br.close();
                String msg = err.toString();
                // Extract error message from JSON if possible
                try {
                    JSONObject ej = new JSONObject(msg);
                    msg = ej.optJSONObject("error") != null
                            ? ej.getJSONObject("error").optString("message", msg) : msg;
                } catch (Exception ignored) {}
                if (msg.length() > 200) msg = msg.substring(0, 200);
                cb.onError("API Hatası " + code + ": " + msg);
                return;
            }

            StringBuilder sb = new StringBuilder();
            String line; while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            JSONObject resp = new JSONObject(sb.toString());
            JSONArray candidates = resp.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                cb.onError("Boş yanıt alındı.");
                return;
            }

            JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
            if (content == null) { cb.onError("İçerik yok."); return; }

            JSONArray parts = content.optJSONArray("parts");
            if (parts == null) { cb.onError("Parça yok."); return; }

            StringBuilder textOut = new StringBuilder();
            JSONArray toolCalls = new JSONArray();

            for (int i = 0; i < parts.length(); i++) {
                JSONObject part = parts.getJSONObject(i);
                if (part.has("text"))         textOut.append(part.getString("text"));
                else if (part.has("functionCall")) toolCalls.put(part.getJSONObject("functionCall"));
            }

            String responseText = textOut.toString().trim();

            // Add model turn to history
            addToHistory("model", responseText.isEmpty() ? "." : responseText);

            cb.onResponse(responseText, toolCalls);

        } catch (Exception e) {
            cb.onError("Bağlantı hatası: " + e.getClass().getSimpleName() + " — " + e.getMessage());
        }
    }

    public void clearHistory() {
        for (int i = history.length() - 1; i >= 0; i--) history.remove(i);
    }

    // ── System Prompt ─────────────────────────────────────────────────────

    public static String buildSystemPrompt(String userName, String memStr) {
        String now = new SimpleDateFormat("dd MMMM yyyy, EEEE — HH:mm", new Locale("tr")).format(new Date());
        String name = (userName != null && !userName.isEmpty()) ? userName : "kullanıcı";

        return "Sen MFD'sin — " + name + " için çalışan kişisel Android AI asistanısın.\n"
                + "Geliştirici: Mehmet Fatih DURSUN\n"
                + "Şu anki zaman: " + now + "\n\n"
                + (memStr != null && !memStr.isEmpty() ? memStr + "\n" : "")
                + "KURALLAR:\n"
                + "- Türkçe konuş, kısa ve net ol\n"
                + "- Kullanıcı senden bir uygulama açmasını, mesaj göndermesini, tarayıcıda işlem yapmasını isterse "
                + "ilgili aracı kullan\n"
                + "- Kullanıcı onayı olmadan hiçbir işlem yapma — her önemli eylemden önce onay iste\n"
                + "- Araçları gerçekten kullan, asla taklit etme\n"
                + "- Önemli bilgileri save_memory ile kaydet\n\n"
                + "ARAÇLAR:\n"
                + "open_app, sys_info, get_weather, get_calendar_events, add_calendar_event,\n"
                + "delete_calendar_event, get_reminders, add_reminder, browser_control,\n"
                + "play_media, send_whatsapp, send_sms, save_memory, delete_memory\n";
    }

    // ── Tool Declarations ─────────────────────────────────────────────────

    public static JSONArray buildToolDeclarations() {
        try {
            JSONArray t = new JSONArray();

            t.put(tool("open_app", "Android uygulaması açar (Spotify, YouTube, WhatsApp, Instagram vb.)",
                    new String[]{"app_name"}, new String[]{"Uygulama adı"}, new String[]{"app_name"}));

            t.put(tool("sys_info", "Sistem bilgisi: pil, RAM, disk, saat, tarih, ağ",
                    new String[]{"query"}, new String[]{"battery|ram|disk|time|date|network|all"}, new String[]{"query"}));

            t.put(tool("get_weather", "Hava durumu bilgisi",
                    new String[]{"location"}, new String[]{"Şehir adı (boş bırakılırsa varsayılan)"}, new String[]{}));

            t.put(tool("get_calendar_events", "Takvim etkinliklerini listeler",
                    new String[]{"query", "limit"},
                    new String[]{"today|tomorrow|week|all", "Maksimum sayı"}, new String[]{"query"}));

            t.put(tool("add_calendar_event", "Takvime etkinlik ekler",
                    new String[]{"title", "start_iso", "end_iso", "notes", "location", "all_day"},
                    new String[]{"Başlık", "Başlangıç ISO tarihi", "Bitiş ISO (opsiyonel)",
                            "Not (opsiyonel)", "Konum (opsiyonel)", "Tüm gün boolean"},
                    new String[]{"title", "start_iso"}));

            t.put(tool("delete_calendar_event", "Takvimden etkinlik siler",
                    new String[]{"title"}, new String[]{"Etkinlik başlığı"}, new String[]{"title"}));

            t.put(tool("get_reminders", "Anımsatıcıları listeler",
                    new String[]{"query", "limit"},
                    new String[]{"all|upcoming|today", "Maksimum sayı"}, new String[]{"query"}));

            t.put(tool("add_reminder", "Anımsatıcı ve alarm ekler",
                    new String[]{"title", "due_iso", "notes"},
                    new String[]{"Başlık", "Tarih/saat ISO (opsiyonel)", "Not (opsiyonel)"},
                    new String[]{"title"}));

            t.put(tool("browser_control", "Tarayıcıda URL açar, arama yapar veya YouTube'da video açar",
                    new String[]{"action", "url", "query"},
                    new String[]{"open_url|search|play_youtube", "URL (open_url için)", "Arama sorgusu"},
                    new String[]{"action"}));

            t.put(tool("play_media", "YouTube veya Spotify'da içerik oynatır",
                    new String[]{"query", "provider"},
                    new String[]{"Arama sorgusu", "youtube|spotify|auto"},
                    new String[]{"query"}));

            t.put(tool("send_whatsapp", "WhatsApp'tan mesaj gönderir (kullanıcı onayı sonrası)",
                    new String[]{"phone_or_name", "message"},
                    new String[]{"Telefon numarası veya kişi adı", "Gönderilecek mesaj"},
                    new String[]{"phone_or_name", "message"}));

            t.put(tool("send_sms", "SMS gönderir",
                    new String[]{"phone", "message"},
                    new String[]{"Telefon numarası", "Mesaj içeriği"},
                    new String[]{"phone", "message"}));

            t.put(tool("save_memory", "Önemli bilgiyi kalıcı belleğe kaydeder",
                    new String[]{"category", "key", "value"},
                    new String[]{"identity|preferences|projects|notes", "Anahtar", "Değer"},
                    new String[]{"category", "key", "value"}));

            t.put(tool("delete_memory", "Hafızadan kayıt siler",
                    new String[]{"category", "key", "match_text"},
                    new String[]{"Kategori", "Anahtar", "Eşleşme metni"},
                    new String[]{}));

            return t;
        } catch (Exception e) { return new JSONArray(); }
    }

    private static JSONObject tool(String name, String desc,
                                    String[] params, String[] descs, String[] required) throws Exception {
        JSONObject t = new JSONObject();
        t.put("name", name);
        t.put("description", desc);
        JSONObject props = new JSONObject();
        for (int i = 0; i < params.length; i++)
            props.put(params[i], new JSONObject().put("type", "STRING").put("description", descs[i]));
        JSONArray req = new JSONArray();
        for (String r : required) req.put(r);
        t.put("parameters", new JSONObject().put("type", "OBJECT").put("properties", props).put("required", req));
        return t;
    }
}
