package com.mfd.assistant;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {

    private static final String API_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

    public interface Callback {
        void onResponse(String text, JSONArray toolCalls);
        void onError(String error);
    }

    private final String apiKey;
    private final String systemPrompt;
    private final JSONArray toolDefs;
    private final JSONArray history = new JSONArray();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();

    public GeminiClient(String apiKey, String systemPrompt, JSONArray toolDefs) {
        this.apiKey       = apiKey;
        this.systemPrompt = systemPrompt;
        this.toolDefs     = toolDefs;
    }

    public void sendMessage(String userText, Callback cb) {
        exec.execute(() -> {
            try {
                JSONObject userTurn = new JSONObject();
                userTurn.put("role", "user");
                userTurn.put("parts", new JSONArray().put(new JSONObject().put("text", userText)));
                history.put(userTurn);
                doCall(cb);
            } catch (Exception e) {
                cb.onError("Hata: " + e.getMessage());
            }
        });
    }

    public void sendToolResult(String name, String result, Callback cb) {
        exec.execute(() -> {
            try {
                JSONObject turn = new JSONObject();
                turn.put("role", "user");
                turn.put("parts", new JSONArray().put(new JSONObject()
                    .put("functionResponse", new JSONObject()
                        .put("name", name)
                        .put("response", new JSONObject().put("result", result)))));
                history.put(turn);
                doCall(cb);
            } catch (Exception e) {
                cb.onError("Tool hatası: " + e.getMessage());
            }
        });
    }

    private void doCall(Callback cb) throws Exception {
        // 1. Bağlan
        URL url = new URL(API_URL + "?key=" + apiKey);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(60000);

        // 2. Body oluştur
        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject()
            .put("parts", new JSONArray().put(new JSONObject().put("text", systemPrompt))));
        body.put("contents", history);
        if (toolDefs != null && toolDefs.length() > 0) {
            body.put("tools", new JSONArray()
                .put(new JSONObject().put("functionDeclarations", toolDefs)));
        }
        body.put("generationConfig", new JSONObject()
            .put("temperature", 0.7)
            .put("maxOutputTokens", 800));

        // 3. Gönder
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.toString().getBytes("UTF-8"));
        }

        // 4. Yanıtı oku
        int code = conn.getResponseCode();
        StringBuilder sb = new StringBuilder();
        BufferedReader br;

        if (code == 200) {
            br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        } else {
            br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String msg = sb.toString();
            try {
                JSONObject ej = new JSONObject(msg);
                if (ej.has("error")) msg = ej.getJSONObject("error").optString("message", msg);
            } catch (Exception ignored) {}
            if (msg.length() > 200) msg = msg.substring(0, 200);
            cb.onError("API Hatası " + code + ": " + msg);
            return;
        }

        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        // 5. Parse et
        JSONObject resp = new JSONObject(sb.toString());
        JSONArray candidates = resp.optJSONArray("candidates");
        if (candidates == null || candidates.length() == 0) {
            cb.onError("Boş yanıt. API anahtarını kontrol et.");
            return;
        }

        JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
        if (content == null) { cb.onError("İçerik yok."); return; }

        JSONArray parts = content.optJSONArray("parts");
        if (parts == null) { cb.onError("Parça yok."); return; }

        StringBuilder textOut = new StringBuilder();
        JSONArray toolCalls = new JSONArray();

        for (int i = 0; i < parts.length(); i++) {
            JSONObject part = parts.getJSONObject(i);
            if (part.has("text")) {
                textOut.append(part.getString("text"));
            } else if (part.has("functionCall")) {
                toolCalls.put(part.getJSONObject("functionCall"));
            }
        }

        String text = textOut.toString().trim();

        // Model yanıtını geçmişe ekle
        JSONObject modelTurn = new JSONObject();
        modelTurn.put("role", "model");
        modelTurn.put("parts", new JSONArray().put(new JSONObject()
            .put("text", text.isEmpty() ? "." : text)));
        history.put(modelTurn);

        cb.onResponse(text, toolCalls);
    }

    public void clearHistory() {
        for (int i = history.length() - 1; i >= 0; i--) history.remove(i);
    }

    public static String buildSystemPrompt(String userName, String memStr) {
        String now = new SimpleDateFormat("dd MMMM yyyy, EEEE HH:mm",
            new Locale("tr")).format(new Date());
        String name = (userName != null && !userName.isEmpty()) ? userName : "kullanıcı";
        return "Sen MFD'sin, " + name + " icin Android AI asistani.\n"
            + "Gelistirici: Mehmet Fatih DURSUN\n"
            + "Zaman: " + now + "\n"
            + (memStr != null && !memStr.isEmpty() ? memStr + "\n" : "")
            + "Turkce konus. Kisa ve net ol. Araclari kullan.";
    }

    public static JSONArray buildToolDeclarations() {
        try {
            JSONArray t = new JSONArray();
            t.put(tool("open_app","Uygulama acar",new String[]{"app_name"},new String[]{"Ad"},new String[]{"app_name"}));
            t.put(tool("sys_info","Sistem bilgisi",new String[]{"query"},new String[]{"battery|ram|disk|time|date|all"},new String[]{"query"}));
            t.put(tool("get_weather","Hava durumu",new String[]{"location"},new String[]{"Sehir"},new String[]{}));
            t.put(tool("get_calendar_events","Takvim",new String[]{"query","limit"},new String[]{"today|tomorrow|week|all","Sayi"},new String[]{"query"}));
            t.put(tool("add_calendar_event","Etkinlik ekle",new String[]{"title","start_iso","end_iso","notes","location"},new String[]{"Baslik","Baslangic","Bitis","Not","Konum"},new String[]{"title","start_iso"}));
            t.put(tool("delete_calendar_event","Etkinlik sil",new String[]{"title"},new String[]{"Baslik"},new String[]{"title"}));
            t.put(tool("add_reminder","Anımsatıcı ekle",new String[]{"title","due_iso","notes"},new String[]{"Baslik","Tarih","Not"},new String[]{"title"}));
            t.put(tool("get_reminders","Anımsatıcıları listele",new String[]{"query"},new String[]{"all|today"},new String[]{"query"}));
            t.put(tool("browser_control","Tarayici",new String[]{"action","url","query"},new String[]{"open_url|search|play_youtube","URL","Sorgu"},new String[]{"action"}));
            t.put(tool("play_media","Muzik/video",new String[]{"query","provider"},new String[]{"Arama","youtube|spotify|auto"},new String[]{"query"}));
            t.put(tool("send_whatsapp","WhatsApp mesaj",new String[]{"phone_or_name","message"},new String[]{"Numara/isim","Mesaj"},new String[]{"phone_or_name","message"}));
            t.put(tool("send_sms","SMS gonder",new String[]{"phone","message"},new String[]{"Numara","Mesaj"},new String[]{"phone","message"}));
            t.put(tool("save_memory","Hafizaya kaydet",new String[]{"category","key","value"},new String[]{"Kategori","Anahtar","Deger"},new String[]{"category","key","value"}));
            t.put(tool("delete_memory","Hafizadan sil",new String[]{"category","key","match_text"},new String[]{"Kategori","Anahtar","Eslesme"},new String[]{}));
            return t;
        } catch (Exception e) { return new JSONArray(); }
    }

    private static JSONObject tool(String name, String desc,
            String[] params, String[] descs, String[] required) throws Exception {
        JSONObject t = new JSONObject();
        t.put("name", name); t.put("description", desc);
        JSONObject props = new JSONObject();
        for (int i = 0; i < params.length; i++)
            props.put(params[i], new JSONObject().put("type","STRING").put("description",descs[i]));
        JSONArray req = new JSONArray();
        for (String r : required) req.put(r);
        t.put("parameters", new JSONObject().put("type","OBJECT").put("properties",props).put("required",req));
        return t;
    }
}
