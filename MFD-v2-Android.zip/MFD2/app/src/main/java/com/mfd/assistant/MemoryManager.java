package com.mfd.assistant;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.Iterator;

public class MemoryManager {
    private static final String PREF = "mfd_memory";
    private final SharedPreferences p;

    public MemoryManager(Context ctx) { p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    public JSONObject load() {
        try { return new JSONObject(p.getString("data", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }

    public void save(String category, String key, String value) {
        try {
            JSONObject mem = load();
            JSONObject cat = mem.optJSONObject(category);
            if (cat == null) cat = new JSONObject();
            cat.put(key, value);
            mem.put(category, cat);
            p.edit().putString("data", mem.toString()).apply();
        } catch (Exception ignored) {}
    }

    public String delete(String category, String key, String match) {
        try {
            JSONObject mem = load();
            if (!category.isEmpty() && !key.isEmpty()) {
                JSONObject cat = mem.optJSONObject(category);
                if (cat != null) { cat.remove(key); mem.put(category, cat); }
                p.edit().putString("data", mem.toString()).apply();
                return "Silindi: " + category + "/" + key;
            }
            if (!match.isEmpty()) {
                String needle = match.toLowerCase();
                Iterator<String> cats = mem.keys();
                while (cats.hasNext()) {
                    String c = cats.next();
                    JSONObject cat = mem.optJSONObject(c);
                    if (cat == null) continue;
                    Iterator<String> keys = cat.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        if (k.toLowerCase().contains(needle) || cat.optString(k,"").toLowerCase().contains(needle)) {
                            keys.remove();
                            p.edit().putString("data", mem.toString()).apply();
                            return "Silindi: " + c + "/" + k;
                        }
                    }
                }
            }
            return "Bulunamadı.";
        } catch (Exception e) { return "Hata: " + e.getMessage(); }
    }

    public String toPromptString() {
        JSONObject mem = load();
        if (mem.length() == 0) return "";
        StringBuilder sb = new StringBuilder("[HAFIZA]\n");
        Iterator<String> cats = mem.keys();
        while (cats.hasNext()) {
            String c = cats.next();
            JSONObject cat = mem.optJSONObject(c);
            if (cat == null) continue;
            Iterator<String> keys = cat.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                sb.append("- ").append(c).append("/").append(k).append(": ").append(cat.optString(k)).append("\n");
            }
        }
        return sb.toString();
    }
}
